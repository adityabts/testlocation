<?php
	$conn = new mysqli('localhost','root','','test')or die("Could not connect to mysql".mysqli_error($conn));
?>
